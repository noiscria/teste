import os
from pathlib import Path
from dotenv import load_dotenv

# Força o carregamento do .env na raiz
env_path = Path(__file__).resolve().parent.parent / ".env"
load_dotenv(dotenv_path=env_path)

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
LOG_FILE = "logs/bot.log"
