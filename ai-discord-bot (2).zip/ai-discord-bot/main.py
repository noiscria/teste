import discord
import openai
import logging
import os
from discord.ext import commands
from dotenv import load_dotenv

# Carrega variáveis de ambiente do .env
load_dotenv()

# Configurar logging
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    filename="logs/bot.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

# Configurações do bot
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

# OpenRouter config
openai.api_key = os.getenv("OPENROUTER_API_KEY")
openai.api_base = "https://openrouter.ai/api/v1"

@bot.event
async def on_ready():
    logging.info(f"Bot iniciado como {bot.user}")
    print(f"✅ Bot iniciado como {bot.user}")

@bot.command(name="pergunte")
async def pergunte(ctx, *, pergunta):
    async with ctx.channel.typing():
        try:
            resposta = openai.ChatCompletion.create(
                model="mistralai/mistral-7b-instruct",
                messages=[
                    {"role": "system", "content": "Você é um assistente de programação simples e direto."},
                    {"role": "user", "content": pergunta}
                ],
                max_tokens=600,
                temperature=0.5
            )
            texto = resposta["choices"][0]["message"]["content"]
            await ctx.reply(texto)
            logging.info(f"Resposta enviada para {ctx.author.name}")
        except Exception as e:
            erro = f"❌ Erro ao consultar a IA: {e}"
            await ctx.reply(erro)
            logging.error(str(e))
            print(f"[ERRO] {e}")

bot.run(os.getenv("DISCORD_TOKEN"))
